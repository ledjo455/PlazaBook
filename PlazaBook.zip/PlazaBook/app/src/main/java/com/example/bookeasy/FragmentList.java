package com.example.bookeasy;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentList extends Fragment {

        ListView lv;
        SearchView searchView;
        ArrayAdapter<String> adapter;
        String data[] ={"SERVICES:","- WiFi Connection free","- Transfer Service from/to Airport","- Gym and Wellness SPA"
        ,"- Private Garage","- Congress Center","- Lounge Bar","- Serviced apartment","- Gift Shop","- Events", "- Service"};


    public FragmentList() {

        }


        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            // Inflate the layout for this fragment
            View view = inflater.inflate(R.layout.fragment_list, container, false);
            lv = (ListView) view.findViewById(R.id.idListView);
            adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,data);
            lv.setAdapter(adapter);
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Toast.makeText(getContext(),"These are some of the services that Plaza Tirana offers.", Toast.LENGTH_SHORT).show();
                }
            });
            return view;
        }
    }